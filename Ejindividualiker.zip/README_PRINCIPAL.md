# Soluciones PMDM · DAM 2

Este paquete reúne proyectos Android Studio en Java basados en los cuatro PDF aportados.

## Contenido
- `1_EnrutamientoAvanzado` a `5_NoticiasFP`: las cinco prácticas del Hito 2.
- `6_Huellas_Integrador`: app base del proyecto integrador Patas Amigas.
- `7_Ejercicios_Layouts_Intents`: los cuatro ejercicios de layouts e Intents en una app con menú.

## Abrir
1. Descomprime el ZIP en una carpeta local, por ejemplo `C:\AndroidProjects\Soluciones_PM​​DM_DAM2`.
2. Android Studio → **Open** → selecciona la carpeta de cada proyecto (la que contiene `settings.gradle`).
3. Espera a que Gradle sincronice. Usa JDK 17 y Android SDK 35.
4. Ejecuta cada proyecto en un emulador API 24 o superior.

## Honestidad sobre el alcance
Los PDF no incluyen las fichas completas de implementación para las cinco prácticas del Hito 2, solo sus requisitos y evidencias. Por eso esas cinco carpetas son bases CRUD sencillas para ejecutar y estudiar, no una afirmación de que todos los criterios avanzados (Navigation/SafeArgs, RecyclerView, Room, Material Drawer, etc.) estén terminados. `NOTAS_SOLUCION.md` dentro de cada proyecto enumera qué queda por completar. Los cuatro ejercicios clásicos implementan sus flujos principales; la app Huellas implementa altas y persistencia sencilla, pero aún requiere Room/NavHost/SafeArgs y otras funciones indicadas en su nota.

No incluye APK firmado ni keystore: la firma debe generarse en tu equipo y la clave privada no se debe compartir.
