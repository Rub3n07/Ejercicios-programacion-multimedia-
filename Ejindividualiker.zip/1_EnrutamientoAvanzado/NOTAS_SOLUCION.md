# Enrutamiento avanzado — solución base

Objetivo del ejercicio: Notas con navegación e identificador.

La app permite añadir elementos, validarlos, listarlos y eliminarlos mediante un diálogo. Los elementos se conservan en preferencias locales para que puedas probar el flujo al cerrar y abrir.

**Importante:** esta versión es una base funcional de estudio, no una implementación completa de todos los criterios avanzados del enunciado. Consulta el PDF Hito 2 para las capturas obligatorias. En particular, la ficha exige RecyclerView/Adapter/menús en las prácticas 1 y 2, SharedPreferences + DatePicker + Snackbar en la 3, Room + ExecutorService en la 4, y Material Drawer/Chip/FAB en la 5; esos componentes deben completarse antes de presentar como entrega final.
