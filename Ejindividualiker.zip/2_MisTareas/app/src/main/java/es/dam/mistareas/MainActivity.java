package es.dam.mistareas;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*; import android.graphics.Typeface; import java.util.*;
public class MainActivity extends Activity {
 LinearLayout root, list; EditText input; ArrayList<String> items=new ArrayList<>(); ArrayAdapter<String> adapter; TextView status;
 String title="Mis Tareas 1";
 public void onCreate(Bundle b){super.onCreate(b); build();}
 void build(){ root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,20,20,20); root.setBackgroundColor(0xfff5f7fa); setContentView(root);
 TextView h=new TextView(this); h.setText(title); h.setTextSize(25); h.setTypeface(null,Typeface.BOLD); h.setTextColor(0xff17324d); root.addView(h);
 status=new TextView(this); status.setText("Prioridad: Alta / Media / Baja. Pulsa una tarea para gestionarla."); root.addView(status);
 input=new EditText(this); input.setHint("Escribe aquí..."); root.addView(input);
 LinearLayout actions=new LinearLayout(this); root.addView(actions);
 Button add=btn("Añadir / guardar"); actions.addView(add); add.setOnClickListener(v->addItem());
 Button clear=btn("Limpiar"); actions.addView(clear); clear.setOnClickListener(v->{input.setText("");});
 Button info=btn("Ayuda"); actions.addView(info); info.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Ayuda").setMessage("Introduce un dato y pulsa Añadir. Mantén pulsado un elemento para eliminarlo.").setPositiveButton("Aceptar",null).show());
 list=new LinearLayout(this); list.setOrientation(1); ScrollView sc=new ScrollView(this); sc.addView(list); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); restore(); render(); }
 Button btn(String s){Button b=new Button(this); b.setText(s); return b;}
 void addItem(){String s=input.getText().toString().trim(); if(s.isEmpty()){input.setError("Este campo es obligatorio"); return;} items.add(s); input.setText(""); save(); render();}
 void render(){list.removeAllViews(); if(items.isEmpty()){TextView e=new TextView(this); e.setText("Aún no hay elementos"); e.setPadding(8,24,8,24); list.addView(e);} for(int i=0;i<items.size();i++){final int pos=i; TextView t=new TextView(this); t.setText("• "+items.get(i)); t.setTextSize(18); t.setPadding(14,18,14,18); t.setBackgroundColor(0xffffffff); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,5,0,5); list.addView(t,lp); t.setOnClickListener(v->new AlertDialog.Builder(this).setItems(new String[]{"Eliminar","Cancelar"},(d,w)->{if(w==0){items.remove(pos);save();render();}}).show()); }}
 void save(){getPreferences(0).edit().putString("items",String.join("\n",items)).apply();}
 void restore(){String s=getPreferences(0).getString("items",""); if(!s.isEmpty()) items.addAll(Arrays.asList(s.split("\n")));}
}
