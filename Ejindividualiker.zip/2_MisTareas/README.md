# Mis Tareas 1

Proyecto Android Studio en Java. Abrir la carpeta que contiene `settings.gradle`.

- `minSdk 24`, Java 17 y Android Gradle Plugin 8.7.3.
- Sin carpetas `build/` ni archivos locales del equipo.
- Revisar `NOTAS_SOLUCION.md` para alcance, pruebas y mejoras pendientes.
